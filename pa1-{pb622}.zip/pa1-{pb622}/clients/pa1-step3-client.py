# Step 3: Protocol + Transform Client (starter)
import socket

HOST = "127.0.0.1"
PORT = 50007

c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
c.connect((HOST, PORT))

buffer = b""

while True:
    line = input("Enter a line (or QUIT): ")
    if line == "QUIT":
        break
    # TODO: send line (+ newline) to server
    c.sendall((line + "\n").encode())
   
   # receive until we have a full line ending in '\n'
    while b"\n" not in buffer:
        inputline = c.recv(1024)
        buffer = buffer + inputline

    # split out exactly one reply line; keep any remainder in buffer
    line_bytes, _, buffer = buffer.partition(b"\n")
    reply = line_bytes.decode() 
    

    print(f"sent={line} recv={reply}")

c.close()
