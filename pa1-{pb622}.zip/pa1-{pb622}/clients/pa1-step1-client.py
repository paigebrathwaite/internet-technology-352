# Step 1: Minimal Client (starter)
import socket

HOST = "127.0.0.1"
PORT = 50007

c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# TODO: connect to (HOST, PORT)
c.connect((HOST, PORT))
print("local endpoint:", c.getsockname())
print("server endpoint:", c.getpeername())

# TODO: receive up to 100 bytes, decode, and print
data = c.recv(100)
stringreceived = data.decode('utf-8')

print("The string received was", stringreceived)

c.close()
