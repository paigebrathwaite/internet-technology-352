# Step 4: File I/O Client (starter)
import socket

HOST = "127.0.0.1"
PORT = 50007

c = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
c.connect((HOST, PORT))

buffer = b""

with open("in-proj.txt") as f:
    for line in f:
        msg = line.strip()  # keep as-is per assignment handout
        # TODO: send msg (+ "\n") to the server
        # TODO: receive the transformed reply from the server
        # decode it back to string

        c.sendall((msg + "\n").encode("utf-8"))

        # read until we get the newline that ends the reply
        while b"\n" not in buffer:
            chunk = c.recv(1024)
            buffer += chunk

        # extract exactly one reply line; keep any remainder in buffer
        line_bytes, _, buffer = buffer.partition(b"\n")
        reply = line_bytes.decode("utf-8")

        print(f"sent={msg} recv={reply}")

c.close()
