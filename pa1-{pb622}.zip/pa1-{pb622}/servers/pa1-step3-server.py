# Step 3: Protocol + Transform Server (starter)
import socket

PORT = 50007


def transform(s: str) -> str:
    # TODO: reverse string and swap case
    return s[::-1].swapcase() #python is a mysterious language 

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
s.bind(("", PORT))
s.listen(1)
print("[S] listening on", s.getsockname())

conn, addr = s.accept()
print("[S] accepted connection from", addr)
buffer = ""

while True:
    data = conn.recv(1024)
    if not data:
        break

    buffer = buffer + data.decode()
    # text = data.decode()
    # reply = transform(text)
    # TODO: send reply + newline

    while True:
        newline = buffer.find("\n")
        if newline == -1:
            break  # no full line yet; wait for more data

        input = buffer[:newline]
        buffer = buffer[newline + 1:]  # keep the remainder for next iteration

        reply = transform(input)
        conn.sendall((reply + "\n").encode())

conn.close()
s.close()
