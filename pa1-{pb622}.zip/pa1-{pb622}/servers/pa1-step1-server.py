# Step 1: Minimal Server (starter)
import socket

PORT = 50007

# create socket object
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# TODO: allow quick restarts with SO_REUSEADDR
""" setsockopt(level, optname, value)
Changes options on a socket. In this project we use it to allow the server to restart quickly without waiting (SO_REUSEADDR) 
parameters specify which protocol layer to target, the name of the option to set, and the value to assign to that option: 1 to enable, 0 to 
disable """

s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

# TODO: bind to all interfaces on PORT
# bind((host, port)), binding port 50007 means "listen for calls on port 50007"
s.bind(("127.0.0.1", 50007))

# TODO: listen with backlog 1
s.listen(1)
print("[S] listening on", s.getsockname())

conn, addr = s.accept()
print("[S] accepted connection from", addr)

# TODO: send greeting to client

#send it over in bytes not as a string 
greeting = b"hello omg"
#send over the accepted connection, not the actual socket
conn.sendall(greeting)

conn.close()
s.close()
